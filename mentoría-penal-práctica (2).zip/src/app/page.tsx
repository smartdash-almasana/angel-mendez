import React from 'react';
import { 
  Scale, 
  Users, 
  BookOpen, 
  ArrowRight, 
  ChevronRight, 
  ShieldCheck, 
  Phone, 
  Mail, 
  Lock, 
  MessageCircle 
} from 'lucide-react';
import { PrismaClient } from '@prisma/client';

// Standard dynamic configuration for Next.js App Router
export const dynamic = 'force-dynamic';
export const revalidate = 0;

async function getSettings() {
  const prisma = new PrismaClient();
  try {
    const settings = await prisma.settings.findUnique({
      where: { id: 'global_config' }
    });
    return settings;
  } catch (error) {
    console.warn("Prisma client failed or not initialized in environment. Falling back.", error);
    return { aliasMercadoPago: 'mentoriamendez.mp' };
  } finally {
    await prisma.$disconnect();
  }
}

export default async function Page() {
  const settings = await getSettings();
  const aliasMercadoPago = settings?.aliasMercadoPago || '';

  const getSubLink = () => {
    if (aliasMercadoPago && aliasMercadoPago.trim() !== '') {
      return `https://link.mercadopago.com.ar/${aliasMercadoPago}`;
    }
    // Lógica de resguardo (Fallback) a WhatsApp directo
    return `https://wa.me/5491122334455?text=Hola,%20quiero%20inscribirme%20a%20la%20mentoría%20práctica%20del%20Dr.%2520M%25C3%25A9ndez`;
  };

  const pillars = [
    {
      icon: <Scale className="w-6 h-6 text-amber-400" />,
      title: "Clínica de Casos Vivos y Reales",
      desc: "El aprendizaje no es teórico; se discuten, planifican y supervisan expedientes y casos reales aportados por los propios alumnos, ofreciendo coaching personalizado para audiencias y escritos."
    },
    {
      icon: <Users className="w-6 h-6 text-amber-400" />,
      title: "Comunidad VIP y Soporte Urgente",
      desc: "Acceso directo y continuo a un grupo exclusivo de WhatsApp para evacuar dudas procesales críticas antes de ingresar a un estrado o presentar una defensa de urgencia."
    },
    {
      icon: <BookOpen className="w-6 h-6 text-amber-400" />,
      title: "Especializaciones de Alta Demanda (2026)",
      desc: "Entrenamiento intensivo en litigio práctico adaptado al marco legal vigente: Litigio estratégico bajo la nueva Ley Penal Juvenil Argentina, Tácticas avanzadas en Habeas Data, y Limpieza Legal de Perfil Crediticio (Veraz/Nosis/BCRA)."
    }
  ];

  const modules = [
    { num: "01", name: "Análisis Integral del Caso y Carpeta Técnica", duration: "Módulo Inicial" },
    { num: "02", name: "Simulación de Audiencias Orales de Excarcelación", duration: "Práctica en Estraño" },
    { num: "03", name: "Estrategias de Litigio Penal Juvenil Argentino", duration: "Leyes Vigentes" },
    { num: "04", name: "Habeas Data y Reclamos ante Veraz, Nosis y BCRA", duration: "Sustanciación" }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-400 overflow-x-hidden">
      
      {/* Header Premium matching top identity */}
      <header className="border-b border-slate-800/50 bg-slate-950/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-amber-500 rounded-sm flex items-center justify-center shadow-lg shadow-amber-500/15">
              <span className="text-slate-950 font-bold text-xl font-serif">M</span>
            </div>
            <div className="flex flex-col">
              <span className="font-serif tracking-wide text-lg font-bold text-amber-500">
                Méndez <span className="text-slate-400 font-light font-sans text-sm">Legal</span>
              </span>
              <span className="text-[9px] tracking-[0.25em] text-slate-500 uppercase font-mono">Mentoría Penal Práctica</span>
            </div>
          </div>
          
          <nav className="hidden md:flex space-x-8 text-sm font-medium text-slate-400 uppercase tracking-widest">
            <a href="#pilares" className="hover:text-amber-400 transition-colors text-[11px]">Ejes Prácticos</a>
            <a href="#programa" className="hover:text-amber-400 transition-colors text-[11px]">Especialidades</a>
            <a href="#estrat" className="hover:text-amber-400 transition-colors text-[11px]">Filosofía</a>
            <a href="#contacto" className="hover:text-amber-400 transition-colors text-[11px]">Mensaje Directo</a>
          </nav>

          <div className="flex items-center space-x-4">
            <a
              href="#suscripcion"
              className="inline-flex text-[10px] uppercase tracking-widest bg-amber-500 text-slate-950 font-bold px-5 py-2.5 rounded-full shadow-lg shadow-amber-500/10 hover:bg-amber-400 hover:shadow-amber-500/20 transition-all duration-200"
            >
              Inscribirse
            </a>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-24 pb-32 flex flex-col items-center justify-center border-b border-slate-800/50 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.04)_0,transparent_60%)] pointer-events-none" />
        <div className="absolute inset-0 opacity-[0.02] bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />

        <div className="max-w-4xl mx-auto px-6 text-center z-10">
          <div className="inline-block px-3 py-1 mb-8 text-[10px] font-bold tracking-[0.2em] uppercase bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded-full">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse mr-2" />
            INSCRIBIENDO AL CICLO PRACTICO 2026
          </div>

          <h1 className="font-serif text-5xl sm:text-6xl md:text-7xl font-light tracking-tight text-white mb-6 leading-[1.1]">
            Mentoría Penal Práctica <br />
            <span className="text-amber-500 italic font-normal">Dr. Ángel Méndez</span>
          </h1>

          <p className="text-base sm:text-lg md:text-xl text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed font-sans">
            De la teoría a los tribunales. Transformá la inseguridad del abogado recién graduado en la pericia de un experto. Aprendé a defender en la trinchera jurídica y a resolver casos reales desde el primer día bajo la supervisión de un penalista senior.
          </p>

          <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
            <a
              href={getSubLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-4 rounded-full font-bold text-sm tracking-widest uppercase transition-all shadow-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 hover:from-amber-400 hover:to-amber-500 hover:shadow-amber-500/20 active:scale-95 duration-200 group cursor-pointer"
            >
              <span>Suscribirse a la Mentoría</span>
              <ArrowRight className="ml-2 w-4.5 h-4.5 group-hover:translate-x-1 transition-transform" />
            </a>

            <a 
              href="#pilares"
              className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-4 rounded-full font-medium text-sm tracking-widest uppercase bg-white/5 hover:bg-white/10 text-white border border-white/10 transition-all font-sans"
            >
              Ver Propuesta de Valor
            </a>
          </div>

          {/* Trust Indicators */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-20 pt-10 border-t border-white/5 text-center">
            <div>
              <p className="font-serif text-2xl md:text-3xl font-bold text-amber-500">100%</p>
              <p className="text-xs text-slate-500 uppercase tracking-widest mt-1 font-mono">Litigio Práctico</p>
            </div>
            <div>
              <p className="font-serif text-2xl md:text-3xl font-bold text-white">Clínica</p>
              <p className="text-xs text-slate-500 uppercase tracking-widest mt-1 font-mono">De Casos Vivos</p>
            </div>
            <div>
              <p className="font-serif text-2xl md:text-3xl font-bold text-white">VIP</p>
              <p className="text-xs text-slate-500 uppercase tracking-widest mt-1 font-mono">Soporte WhatsApp</p>
            </div>
            <div>
              <p className="font-serif text-2xl md:text-3xl font-bold text-amber-500">2026</p>
              <p className="text-xs text-slate-500 uppercase tracking-widest mt-1 font-mono">Leyes Actualizadas</p>
            </div>
          </div>
        </div>
      </section>

      {/* Pillars of capacity with Glassmorphism */}
      <section className="py-24 max-w-7xl mx-auto px-6" id="pilares">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-mono tracking-widest text-amber-500 uppercase font-bold">MÉTODOS EXCLUSIVOS DE CAPACITACIÓN</span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold mt-2 mb-4 text-white">Ejes Clave de la Mentoría</h2>
          <span className="w-16 h-0.5 bg-amber-500 block mx-auto mb-6" />
          <p className="text-slate-400 text-sm sm:text-base">
            Diseñamos un sistema dinámico enfocado en entregarte las herramientas técnicas que el ejercicio del Derecho Penal en Argentina exige para destacar en Tribunales.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pillars.map((pillar, idx) => (
            <div 
              key={idx}
              className="p-8 rounded-2xl bg-white/[0.02] border border-slate-800/80 backdrop-blur-md flex flex-col justify-between transition-all hover:translate-y-[-6px] duration-250"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center border border-amber-500/20 mb-6">
                  {pillar.icon}
                </div>
                <h3 className="font-serif text-xl font-bold mb-4 text-white leading-snug">{pillar.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{pillar.desc}</p>
              </div>
              <div className="mt-8 pt-4 border-t border-white/5 flex items-center text-xs text-amber-500 font-semibold tracking-wider uppercase">
                <span>Procedimiento de Elite</span>
                <ChevronRight className="w-3.5 h-3.5 ml-1" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Specialty modules */}
      <section className="py-24 bg-zinc-950/30 border-y border-slate-800/50 relative overflow-hidden" id="programa">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(245,158,11,0.02)_0,transparent_55%)] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div className="lg:col-span-4 lg:pr-6">
              <span className="font-serif text-amber-500 text-sm font-bold tracking-widest uppercase block mb-3">PROGRAMA OFICIAL</span>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold mb-6 text-white leading-tight">Capacitación en Prácticas de Alta Complejidad</h2>
              <p className="text-slate-400 text-sm sm:text-base leading-relaxed mb-6 font-sans">
                Formamos defensores independientes y sumamente eficaces en Argentina. Revisarás en profundidad los flujos procesales complejos, la redacción de recusaciones penales de rigor y litigio de marcas en derecho ejecutivo comercial.
              </p>
              <div className="p-4 rounded-xl bg-amber-500/5 border border-amber-500/10 flex items-start space-x-3">
                <ShieldCheck className="w-5 h-5 text-amber-400 mt-0.5 shrink-0" />
                <div className="text-xs text-slate-350 leading-normal font-sans">
                  <strong className="text-white block mb-0.5">Certificación Oficial</strong>
                  Recibirás una distinción oficial de especialización académica firmada por el Dr. Ángel Méndez.
                </div>
              </div>
            </div>

            <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {modules.map((m, idx) => (
                <div key={idx} className="p-6 rounded-xl bg-white/[0.01] border border-slate-800/80 hover:border-amber-500/20 hover:bg-white/[0.02] transition-all flex flex-col justify-between h-44 group">
                  <div className="flex justify-between items-start">
                    <span className="text-slate-600 font-mono text-xs tracking-widest uppercase font-bold group-hover:text-amber-500 transition-colors">PLENO {m.num}</span>
                    <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-white/5 text-slate-400 border border-white/5">{m.duration}</span>
                  </div>
                  <div>
                    <h4 className="font-serif text-base font-bold text-white group-hover:text-amber-400 transition-colors leading-snug">{m.name}</h4>
                    <p className="text-slate-500 text-[11px] mt-2 font-mono">Estudio Jurídico Dr. Méndez & Soc.</p>
                  </div>
                </div>
              ))}
            </div>

          </div>
        </div>
      </section>

      {/* Philosophy block */}
      <section className="py-24 max-w-7xl mx-auto px-6 text-center" id="estrat">
        <div className="max-w-3xl mx-auto p-8 md:p-12 rounded-3xl bg-gradient-to-b from-white/[0.01] to-transparent border border-slate-800/80 backdrop-blur-lg relative">
          <span className="text-slate-800 font-serif text-9xl absolute -top-4 left-6 pointer-events-none select-none">“</span>
          
          <p className="font-serif text-lg md:text-xl text-slate-350 relative z-10 leading-relaxed mb-8 italic">
            "En el Derecho Penal, el mínimo error procesal le cuesta la libertad a tu deponente. La mentoría práctica del Dr. Méndez provee ese entrenamiento bajo fuego que la universidad nunca te dió: aprender a reaccionar, recusar bases fiscales y consolidar una teoría del caso indestructible en audiencias orales reales."
          </p>

          <div className="mt-6 flex flex-col items-center">
            <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/20 text-amber-500 flex items-center justify-center font-serif font-bold text-lg rounded-full mb-3 shadow">
              AM
            </div>
            <h4 className="font-serif text-base font-semibold text-white">Dr. Ángel Méndez</h4>
            <p className="text-slate-500 text-xs uppercase tracking-widest mt-1 font-mono">Socio Fundador — Especialista en Litigación Penal</p>
          </div>
        </div>
      </section>

      {/* Checkout and action subscription details */}
      <section className="py-24 border-t border-slate-800/50 relative" id="suscripcion">
        <div className="absolute inset-0 bg-gradient-to-t from-amber-500/[0.01] to-transparent pointer-events-none" />
        
        <div className="max-w-4xl mx-auto px-6">
          <div className="p-8 md:p-12 rounded-3xl bg-zinc-900 border border-amber-500/20 relative shadow-2xl">
            <div className="absolute top-0 right-12 transform -translate-y-1/2">
              <span className="px-3.5 py-1 text-[10px] font-mono font-bold tracking-widest bg-amber-500 text-slate-950 rounded-full shadow-lg font-bold">ALTA DIRECTA SUCURSAL</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
              
              <div className="md:col-span-7">
                <span className="text-xs font-bold font-mono tracking-widest text-amber-500 uppercase block mb-2">ADMISIÓN DE ABOGADOS MATRICULADOS</span>
                <h3 className="font-serif text-2xl md:text-3xl font-bold text-white mb-4">Suscripción Regular Mensual</h3>
                
                <ul className="space-y-3.5 text-sm text-slate-300">
                  <li className="flex items-center space-x-2.5">
                    <ShieldCheck className="w-4.5 h-4.5 text-amber-500 shrink-0" />
                    <span>Clases magistrales de Clínica de Casos recurrentes</span>
                  </li>
                  <li className="flex items-center space-x-2.5">
                    <ShieldCheck className="w-4.5 h-4.5 text-amber-500 shrink-0" />
                    <span>Espacios de evacuación de dudas inmediatas vía WhatsApp</span>
                  </li>
                  <li className="flex items-center space-x-2.5">
                    <ShieldCheck className="w-4.5 h-4.5 text-amber-500 shrink-0" />
                    <span>Soporte prioritario y plantillas de impugnaciones penales</span>
                  </li>
                </ul>
              </div>

              <div className="md:col-span-5 bg-black/45 border border-slate-800/70 p-6 rounded-2xl text-center">
                <span className="text-slate-500 text-xs tracking-widest uppercase block mb-1">PROGRAMA COMPLETO</span>
                <p className="text-4xl font-serif font-bold text-white mb-2">AR$ 35.000<span className="text-sm font-sans text-slate-400 font-normal"> / mes</span></p>
                <p className="text-[11px] text-slate-500 mb-6 leading-relaxed">Alta segura automática desde la pasarela nacional homologada de Mercado Pago.</p>
                
                <a
                  href={getSubLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center px-6 py-3.5 rounded-xl font-bold text-xs tracking-wider uppercase bg-amber-500 hover:bg-amber-400 text-slate-950 hover:shadow-amber-500/20 active:scale-95 transition-all duration-200 cursor-pointer shadow-lg"
                >
                  <span>Suscribirse a la Mentoría</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-2" />
                </a>
                
                {(!aliasMercadoPago || aliasMercadoPago.trim() === '') && (
                  <p className="text-[10px] text-amber-500/80 mt-2 font-mono">Modo seguro: redirección WhatsApp de inscripción inmediata activa.</p>
                )}
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* Direct Contact & Support */}
      <section className="py-24 max-w-7xl mx-auto px-6 border-b border-slate-800/50" id="contacto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          <div className="lg:col-span-5 p-8 rounded-2xl bg-white/[0.01] border border-slate-800/80 flex flex-col justify-between">
            <div>
              <span className="font-serif text-amber-500 text-sm font-bold tracking-widest uppercase block mb-2">ESTUDIO CENTRAL</span>
              <h3 className="font-serif text-2xl font-bold text-white mb-6">Asesoramiento Directo Personalizado</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-8">
                Hable directo con la coordinación académica o el Dr. Méndez para tramitar su matriculación o alta en la comunidad procesal penal argentina de elite.
              </p>
            </div>

            <div className="space-y-4 text-xs font-mono text-slate-400 pt-6 border-t border-slate-800/50">
              <div className="flex items-center space-x-3">
                <Phone className="w-4.5 h-4.5 text-amber-500 shrink-0" />
                <span>+54 9 11 2233-4455 (WhatsApp Consultas)</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-4.5 h-4.5 text-amber-500 shrink-0" />
                <span>consultas@drluisangelmendez.com.ar</span>
              </div>
              <div className="flex items-center space-x-3">
                <Lock className="w-4.5 h-4.5 text-amber-500 shrink-0" />
                <span>Matrículas Certificadas & Control de Privacidad Homologado</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 bg-zinc-950 border border-slate-800/80 p-8 rounded-2xl shadow-xl flex flex-col justify-center text-center">
            <h4 className="font-serif text-lg font-bold text-white pb-3 border-b border-slate-800/55 mb-6">Solicitud Académica</h4>
            <p className="text-slate-400 text-sm mb-8 leading-relaxed">
              ¿Deseas iniciar de inmediato tu alta o evacuar dudas específicas sobre los contenidos, plazos y derivaciones penales de las fases de estudio? Envía un mensaje directo interactivo por WhatsApp.
            </p>
            <a 
              href={`https://wa.me/5491122334455?text=Hola%20Dr.%20Luis%20Angel%20Mendez.%20Me%20contacto%20sobre%20la%20Mentoria%20Penal%20Practica.`}
              target="_blank"
              rel="noreferrer"
              className="w-full inline-flex items-center justify-center px-6 py-4 rounded-xl font-bold text-xs tracking-wider uppercase bg-amber-500 hover:bg-amber-400 text-slate-950 active:scale-[0.98] transition-all cursor-pointer shadow-lg hover:shadow-amber-500/10"
            >
              <span>Preguntar por WhatsApp</span>
              <MessageCircle className="w-4 h-4 ml-2" />
            </a>
          </div>

        </div>
      </section>

      {/* Elegant dark footer */}
      <footer className="mt-auto border-t border-slate-800/50 bg-slate-950 py-12 text-slate-600 text-[10px] tracking-widest uppercase font-mono">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
          <div className="flex items-center space-x-3">
            <Scale className="text-amber-500/50 w-4.5 h-4.5" />
            <span className="font-serif tracking-widest text-xs text-slate-400">ESTUDIO DR. ÁNGEL MÉNDEZ</span>
          </div>

          <p className="text-center md:text-left leading-relaxed max-w-md text-[9px] text-slate-500">
            &copy; {new Date().getFullYear()} Mentoría Penal Práctica. Todos los derechos reservados. <br />
            Litigación penal y asesoramiento de alta complejidad. Acceso restringido • Servidores NeonDB.
          </p>

          <div className="flex space-x-6">
            <a href="#contacto" className="hover:text-amber-400 transition-colors text-[9px]">Código Penal Arg.</a>
            <a href="#contacto" className="hover:text-amber-400 transition-colors text-[9px]">Ética de Foro</a>
          </div>
        </div>
      </footer>

    </div>
  );
}
